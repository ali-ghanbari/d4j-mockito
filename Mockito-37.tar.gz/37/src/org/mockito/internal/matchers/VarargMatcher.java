package org.mockito.internal.matchers;

import java.io.Serializable;

public interface VarargMatcher extends Serializable {
}
