package org.mockito.internal.creation.instance;

public class InstantationException extends RuntimeException {

    public InstantationException(String message, Throwable cause) {
        super(message, cause);
    }
}
