package org.mockitousage.testng;

import java.util.List;
import java.util.Map;

public class SomeType {
    List list;
    Map map;
}
